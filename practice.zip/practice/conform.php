<?php
$name = $_POST['nm'];
$email = $_POST['em'];
$tel = $_POST['tel'];
$gender = $_POST['gen'];

$con = new mysqli($host = "localhost", $user = "root", $password = "", $database = "db3");

if($con->connect_error){
    echo "error";

}

else{
    $smpt = $con->prepare("INSERT INTO `tbl3`(name, email, tel, gender)VALUES(?,?,?,?)");

    $smpt->bind_param("ssss", $name, $email, $tel, $gender);
    $smpt->execute();
    $smpt->close();
    $con->close();
    echo "login done successfully";
}



?>