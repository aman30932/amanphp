<?php

$con = new mysqli($host = "localhost", $user = "root", $password = "", $db = "db1");


$sql = "INSERT INTO `tbl1`(`name`,`designation`,`salary`,`address`)VALUES ('Aman', 'DEVELOPER', '20000')";

if ($con->query($sql)){
    echo "submited";
}

$sql = "CREATE TABLE `tbl1` (`id` int primary key auto_increment, `name` varchar(50))"; 


$sql = "ALTER TABLE `tbl1` ADD COLUMN (`designation` varchar(40))";
$sql = "ALTER TABLE `tbl1` ADD COLUMN (`salary` varchar(40))";
$sql = "ALTER TABLE `tbl1` ADD COLUMN (`address` varchar(40))";



$con->query($sql);
// if ($con->connect_error){
//     echo "error";
// }


// else{
//     $db = "CREATE TABLE `tbl1` (`id` int primary key auto_increment, name varchar(50))";
//     if ($con->query($db)){
//         echo "done";
//     }
// }

?>
